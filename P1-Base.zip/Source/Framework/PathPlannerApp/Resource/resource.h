﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PathPlanner.rc
//
#define IDI_UFL_CAP4053                 2
#define IDS_APP_TITLE                   101
#define IDS_LV_GLOBALS                  102
#define IDS_LV_PARAMETERS               103
#define IDS_LVC_VALUE                   104
#define IDS_LVC_GLOBAL_SETTING          105
#define IDS_LVC_PARAM_NAME              106
#define IDD_ABOUTBOX                    107
#define IDM_APP_EXIT                    108
#define IDM_APP_ABOUT                   109
#define IDC_PATHPLANNER                 110
#define IDC_TILEGRID                    111
#define IDR_MAINFRAME                   128
#define IDI_OPEN                        129
#define IDI_STOP                        130
#define IDI_START                       131
#define IDI_GOAL                        132
#define IDI_PAUSE                       133
#define IDI_PLAY                        134
#define IDI_PLAY_PAUSE                  135
#define IDI_PLAY_END                    136
#define IDM_APP_OPEN                    32771
#define IDM_PATHPLANNER_RESET           32772
#define IDM_PATHPLANNER_SET_START       32773
#define IDM_PATHPLANNER_SET_GOAL        32774
#define IDM_PATHPLANNER_RUN             32775
#define IDM_PATHPLANNER_STEP            32776
#define IDM_PATHPLANNER_TIME_RUN        32777
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
