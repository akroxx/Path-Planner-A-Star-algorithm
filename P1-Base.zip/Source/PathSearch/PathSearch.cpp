namespace ufl_cap4053
{
	namespace searches
	{
		// CLASS DEFINITION GOES HERE
	}
}  // close namespace ufl_cap4053::searches
